
/******************************************************************************
                              Enums
******************************************************************************/

// NOTE: These need to match the names of your ".env" files
export enum NodeEnvs {
  Dev = 'development',
  Test = 'test',
  Production = 'production'
}
