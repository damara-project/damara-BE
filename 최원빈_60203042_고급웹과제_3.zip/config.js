"use strict";
/* eslint-disable n/no-process-env */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const dotenv_1 = __importDefault(require("dotenv"));
const module_alias_1 = __importDefault(require("module-alias"));
// Check the env
const NODE_ENV = (process.env.NODE_ENV ?? 'development');
const resolveRoot = () => {
    const dir = __dirname;
    if (dir.endsWith(path_1.default.sep + 'dist')) {
        return path_1.default.resolve(dir, '..');
    }
    return dir;
};
const rootDir = resolveRoot();
const candidateEnvPaths = [
    path_1.default.join(rootDir, 'config', `.env.${NODE_ENV}`),
    path_1.default.join(rootDir, `.env.${NODE_ENV}`),
    path_1.default.join(rootDir, '.env'),
];
let envLoaded = false;
for (const envPath of candidateEnvPaths) {
    if (fs_1.default.existsSync(envPath)) {
        dotenv_1.default.config({ path: envPath });
        envLoaded = true;
        break;
    }
}
if (!envLoaded) {
    dotenv_1.default.config();
}
// Configure moduleAlias
if (__filename.endsWith('js')) {
    module_alias_1.default.addAlias('@src', __dirname + '/dist');
}
